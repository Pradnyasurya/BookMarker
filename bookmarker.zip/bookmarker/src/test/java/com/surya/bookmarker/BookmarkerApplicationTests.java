package com.surya.bookmarker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookmarkerApplicationTests {

	@Test
	void contextLoads() {
	}

}
